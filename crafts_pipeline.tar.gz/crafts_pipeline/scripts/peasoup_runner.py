#!/usr/bin/env python3
# 12/3/2026
# Edit Log
# included min sn as a flag 
import os
import argparse
import subprocess
import re
import xml.etree.ElementTree as ET
import pandas as pd
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger("peasoup_runner")


# ----------------------------------------------------------------------
# Read filterbank header safely
# ----------------------------------------------------------------------
def read_header_params(fpath):

    raw = subprocess.check_output(["header", fpath])
    out = raw.decode("utf-8", errors="ignore")

    values = {}

    for line in out.splitlines():
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        values[key.strip()] = val.strip()

    return {
        "src_ra": values.get("Source RA (J2000)"),
        "src_dec": values.get("Source DEC (J2000)"),
        "fch1": float(values.get("Frequency of channel 1 (MHz)", "nan")),
        "foff": float(values.get("Channel bandwidth      (MHz)", "nan")),
        "nchans": int(values.get("Number of channels", "0")),
        "nbeams": int(values.get("Number of beams", "0")),
        "beamnum": int(values.get("Beam number", "0")),
        "mjd_start": float(values.get("Time stamp of first sample (MJD)", "nan")),
        "greg_date": values.get("Gregorian date (YYYY/MM/DD)"),
        "tsamp_us": float(values.get("Sample time (us)", "nan")),
        "nsamples": int(values.get("Number of samples", "0")),
        "obslen_hr": float(values.get("Observation length (hours)", "nan")),
    }


# ----------------------------------------------------------------------
# XML sanitization
# ----------------------------------------------------------------------
_ILLEGAL_XML_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F]")


def _sanitize_xml_bytes(raw: bytes) -> str:
    head = raw[:200].decode("ascii", errors="ignore")

    enc = None
    m = re.search(r'encoding=[\'"]([A-Za-z0-9_\-]+)[\'"]', head)
    if m:
        enc = m.group(1)

    for codec in ([enc] if enc else []) + ["utf-8", "latin-1"]:
        try:
            text = raw.decode(codec)
            break
        except Exception:
            continue
    else:
        text = raw.decode("latin-1", errors="replace")

    cleaned = _ILLEGAL_XML_RE.sub("", text)
    return cleaned


# ----------------------------------------------------------------------
# Parse Peasoup XML candidates
# ----------------------------------------------------------------------
def parse_candidates_from_xml(cand_list_path: str, fil_prefix: str):

    try:
        with open(cand_list_path, "rb") as f:
            raw = f.read()

        cleaned = _sanitize_xml_bytes(raw)
        root = ET.fromstring(cleaned)

        candidates = root.findall(".//candidates/candidate")
        if not candidates:
            candidates = root.findall(".//candidate")

        def _safe_cast(text, cast, default=None):
            if text is None:
                return default
            try:
                return cast(text)
            except Exception:
                return default

        rows = []
        for cand in candidates:
            period = _safe_cast(cand.findtext("period"), float)
            acc = _safe_cast(cand.findtext("acc"), float)
            dm = _safe_cast(cand.findtext("dm"), float)
            nh = _safe_cast(cand.findtext("nh"), int)
            fft_sn = _safe_cast(cand.findtext("snr"), float)
            cand_no = _safe_cast(cand.get("id"), int)

            rows.append([cand_no, period, acc, dm, nh, fft_sn])

        df = pd.DataFrame(
            rows,
            columns=["cand_no", "period", "acc", "dm", "nh", "fft_sn"]
        )

        out = f"{fil_prefix}.cand"
        df.to_csv(out, index=False, sep="\t")

        log.info(f"Converted XML to CSV: {out} with {len(df)} candidates")
        return out

    except ET.ParseError as e:
        log.error(f"XML parse error after sanitization ({cand_list_path}): {e}")
        return None
    except Exception as e:
        log.error(f"Error parsing XML {cand_list_path}: {e}")
        return None


# ----------------------------------------------------------------------
# Run Peasoup
# ----------------------------------------------------------------------
def run_peasoup(
    filterbank_path,
    results_path,
    dm_start,
    dm_end,
    acc_start,
    acc_end,
    dm_tol,
    fft_size,
    min_sn,
    start_sample=None,
    samples_to_read=None,
):

    try:
        fil_abs = os.path.abspath(filterbank_path)

        if not os.path.exists(fil_abs):
            raise FileNotFoundError(f"Input file not found: {fil_abs}")

        hdr = read_header_params(fil_abs)

        if start_sample is None:
            start_sample = 0

        if samples_to_read is None:
            samples_to_read = int(hdr.get("nsamples", 0))
            if samples_to_read <= 0:
                raise RuntimeError("Could not determine nsamples.")

        tsamp = hdr.get("tsamp_us")

        if tsamp:
            t_start = start_sample * tsamp / 1e6
            t_end = (start_sample + samples_to_read) * tsamp / 1e6
            log.info(f"Processing time range: {t_start:.2f}s → {t_end:.2f}s")
        else:
            log.info(f"Processing samples {start_sample} → {start_sample + samples_to_read}")

        os.makedirs(results_path, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(fil_abs))[0]

        log.info(f"Running peasoup on {fil_abs}")

        cmd = [
            "peasoup", "-p",
            "--dm_start", str(dm_start),
            "--dm_end", str(dm_end),
            "--dm_tol", str(dm_tol),
            "--acc_start", str(acc_start),
            "--acc_end", str(acc_end),
            "--start_sample", str(start_sample),
            "--samples_to_read", str(samples_to_read),
#	    "-z" ,"/fred/oz002/users/vmandaog/pulsar_search/FAST/junk_tests/test_candidate_numbers/manual_rfi_zapping/multibeam/cleaned_fil/final_birdies.zap",
            "-n", "5",
            "-m",str(min_sn),
            "--limit", "15000",
            "--fft_size", str(fft_size),
            "-i", fil_abs,
            "-o", results_path,
        ]

        print("peasoup command is:", " ".join(cmd))

        subprocess.run(cmd, check=True)

        log.info(f"Peasoup completed. Output dir: {results_path}")

        xml_file = os.path.join(results_path, "overview.xml")

        if os.path.exists(xml_file):
            parse_candidates_from_xml(
                xml_file,
                os.path.join(results_path, base_name)
            )
        else:
            log.warning(f"overview.xml not found at: {xml_file}")

        return 0

    except subprocess.CalledProcessError as e:
        log.error(f"Peasoup failed with exit code {e.returncode}")
        return 1
    except Exception as e:
        log.error(f"Error in peasoup processing: {e}")
        return 1


# ----------------------------------------------------------------------
# CLI entry
# ----------------------------------------------------------------------
def main():

    parser = argparse.ArgumentParser(
        description="Run Peasoup pulsar search on a filterbank file",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("filterbank_path")
    parser.add_argument("results_path", nargs="?", default=None)
    parser.add_argument("--start_sample", type=int)
    parser.add_argument("--nsamples", type=int)
    parser.add_argument("--min_sn" , type = float , required = True)
    parser.add_argument("--dm_start", type=float, required=True)
    parser.add_argument("--dm_end", type=float, required=True)
    parser.add_argument("--dm_tol", type=float, default=1.1)
    parser.add_argument("--acc_start", type=int, default=0)
    parser.add_argument("--acc_end", type=int, default=0)
    parser.add_argument("--fft_size", type=int)

    args = parser.parse_args()

    if args.results_path is None:
        fb_dir = os.path.dirname(os.path.abspath(args.filterbank_path))
        fb_base = os.path.splitext(os.path.basename(args.filterbank_path))[0]
        args.results_path = os.path.join(fb_dir, f"{fb_base}_results")
        os.makedirs(args.results_path, exist_ok=True)

    if args.fft_size is None:
        header = read_header_params(args.filterbank_path)
        args.fft_size = header["nsamples"]

    run_peasoup(
        args.filterbank_path,
        args.results_path,
        args.dm_start,
        args.dm_end,
        args.acc_start,
        args.acc_end,
        args.dm_tol,
        args.fft_size,
	args.min_sn,
        args.start_sample,
        args.nsamples,
    )


if __name__ == "__main__":
    main()
