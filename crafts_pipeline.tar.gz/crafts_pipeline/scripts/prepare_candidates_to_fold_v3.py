#!/usr/bin/env python3

import argparse
import os

import pandas as pd
import numpy as np


def parse_chunk_id_from_dirname(dirname, beam_num):
    marker = f"M{beam_num:02d}_"
    idx = dirname.find(marker)
    if idx == -1:
        return None
    after = dirname[idx + len(marker):]
    chunk_id = after.split("_")[0]
    return chunk_id


def discover_all_chunks(base_path, nbeams=19):
    chunk_ids = set()
    beam_folder = os.path.join(base_path, f"{1:02d}")
    if not os.path.isdir(beam_folder):
        return []
    for entry in os.scandir(beam_folder):
        if entry.is_dir() and entry.name.endswith("_candidates"):
            chunk_id = parse_chunk_id_from_dirname(entry.name, 1)
            if chunk_id is not None:
                chunk_ids.add(chunk_id)
    return sorted(chunk_ids)


def load_beams_for_chunk(base_path, chunk_id, nbeams=19):
    dfs = []
    for beam_num in range(1, nbeams + 1):
        beam_folder = os.path.join(base_path, f"{beam_num:02d}")
        if not os.path.isdir(beam_folder):
            print(f"Warning: Beam folder not found: {beam_folder}")
            continue

        # Match only *_candidates directories, not *_birdies
        matched = [
            e.path for e in os.scandir(beam_folder)
            if e.is_dir()
            and e.name.endswith("_candidates")
            and f"M{beam_num:02d}_{chunk_id}_" in e.name
        ]

        if not matched:
            print(f"Warning: No candidates directory found for beam {beam_num:02d}, chunk {chunk_id}")
            continue

        csv_path = os.path.join(matched[0], "candidates_with_beam.csv")
        if not os.path.exists(csv_path):
            print(f"Warning: CSV not found: {csv_path}")
            continue

        df = pd.read_csv(csv_path)
        dfs.append(df)

    if not dfs:
        return pd.DataFrame()
    return pd.concat(dfs, ignore_index=True)


###########################################################################
# Multibeam birdie finder
###########################################################################

# Decimals used to round 1/period into freq_bin. Used by find_birdies AND
# process_chunk so both bin candidates identically.
FREQ_DECIMALS = 9


# 1. Beam geometry: Chen+2025 Table 2 (1420.4 MHz), offsets from M01 [arcmin],
#    beam size = geo-mean FWHM
def beam_geometry():
    rows = [(1,  0.08,  0.00, 2.91), (2,  5.81,  0.07, 2.95), (3,  2.85, -4.92, 2.96),
            (4, -2.88, -4.98, 2.95), (5, -5.62,  0.03, 2.90), (6, -2.73,  4.97, 2.91),
            (7,  3.04,  4.98, 2.90), (8, 11.70,  0.07, 3.03), (9,  8.67, -4.78, 3.01),
            (10, 5.84, -9.86, 3.02), (11, 0.04, -9.90, 2.98), (12, -5.49, -9.96, 3.02),
            (13, -8.41, -4.99, 2.95), (14, -11.30, -0.03, 2.96), (15, -8.41,  4.95, 2.93),
            (16, -5.54,  9.94, 2.98), (17, 0.22,  9.93, 3.00), (18, 6.01, 10.01, 2.97),
            (19, 8.81,  4.98, 2.98)]
    return pd.DataFrame(rows, columns=["beam", "x", "y", "fwhm"]).set_index("beam")


# 2. Beam-to-beam separations [arcmin]
def beam_separations(geom=None):
    g = beam_geometry() if geom is None else geom
    xy = g[["x", "y"]].to_numpy()
    d = np.linalg.norm(xy[:, None, :] - xy[None, :, :], axis=-1)
    return pd.DataFrame(d, index=g.index, columns=g.index)


# Thresholds from the beam model
def _v(dec_deg):
    """Drift rate [arcmin/s]."""
    return 0.2507 * np.cos(np.deg2rad(dec_deg))


def reach(sn_max, sn_min=10, fwhm=3.3):
    """Radius [arcmin] within which a Gaussian-beam source of peak S/N = sn_max
    stays above sn_min."""
    sigma = fwhm / 2.3548
    return sigma * np.sqrt(2 * np.log(np.asarray(sn_max) / sn_min))


def max_windows(sn_max, T_win=25.8, stride=25.8, dec_deg=25., **kw):
    """Max number of windows a point source can stay above sn_min in one beam."""
    t_above = 2 * reach(sn_max, **kw) / _v(dec_deg)          # seconds above sn_min in one beam
    return np.ceil((t_above + T_win) / stride)


def max_sep(sn_max, T_win=25.8, dec_deg=25., **kw):
    """Max beam separation [arcmin] over which a point source can be detected
    in one window."""
    R = reach(sn_max, **kw)
    return np.hypot(_v(dec_deg) * T_win + 2 * R, 2 * R)


def find_birdies(df_all, sn_min=10, dm_min=0, dm_max=500, T_win=25.6, stride=12.8,
                 dec_deg=25., fwhm=3.3, n_all=19):
    kw = dict(sn_min=sn_min, fwhm=fwhm)
    SEP = beam_separations().to_numpy()

    # frequency binning on the FULL candidate list
    full = df_all.copy()
    full["freq_bin"] = (1.0 / full["period"]).round(FREQ_DECIMALS)

    # 3. detection subset: only S/N > sn_min (and DM range) is used to FIND birdies
    df = full[(full.fft_sn > sn_min) & full.dm.between(dm_min, dm_max)]
    if df.empty:
        return full.assign(rfi_rep=False), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    # 4. window persistence in ONE beam
    bw = (df.groupby(["beam", "freq_bin"])
            .agg(n_win=("window", "nunique"), sn_max=("fft_sn", "max")).reset_index())
    bw["n_win_max"] = max_windows(bw.sn_max, T_win, stride, dec_deg, **kw)
    bw["flag_window"] = bw.n_win > bw.n_win_max

    # 5. beam persistence in ONE window
    piv = df.pivot_table(index=["window", "freq_bin"], columns="beam",
                         values="fft_sn", aggfunc="max")
    S = piv.reindex(columns=range(1, 20)).to_numpy()        # beam = 1..19; NaN = not detected
    det = np.isfinite(S)
    j = np.nanargmax(S, axis=1)                             # brightest beam in each group
    wb = pd.DataFrame({"n_beams": det.sum(1),
                       "anchor": j + 1,
                       "sn_max": S[np.arange(len(S)), j],
                       "sep_max": np.where(det, SEP[j], 0).max(1)},   # furthest detected beam from anchor
                      index=piv.index).reset_index()
    wb["sep_allowed"] = max_sep(wb.sn_max, T_win, dec_deg, **kw)
    wb["flag_all"] = wb.n_beams >= n_all                    # condition 1: present in all beams
    wb["flag_sep"] = wb.sep_max > wb.sep_allowed            # condition 2: too far for a point source

    # 6. OR gate -> birdie list (one row per flagged frequency, with the reason counts)
    why = pd.DataFrame({
        "window_persist": bw[bw.flag_window].groupby("freq_bin").size(),
        "all_beams":      wb[wb.flag_all].groupby("freq_bin").size(),
        "separation":     wb[wb.flag_sep].groupby("freq_bin").size()}).fillna(0).astype(int)

    # apply the birdie list to the FULL candidate list; keep one highest-S/N row per birdie
    is_rfi = full.freq_bin.isin(why.index)
    rep = (full[is_rfi].sort_values("fft_sn", ascending=False)
                       .drop_duplicates("freq_bin"))
    final = (pd.concat([full[~is_rfi].assign(rfi_rep=False), rep.assign(rfi_rep=True)])
               .sort_values("fft_sn", ascending=False))

    return final, why, bw, wb


# Candidate filtering

def create_filtered_cands(df):
    try:
        c1 = (df['fft_sn'] >= 8.0) & (df['nh'] > 0)
        c2 = (df['fft_sn'] >= 10) & (df['nh'] == 0)
        c3 = (df['period'] >= 0.03) & (df['period'] <= 0.100) & (df['fft_sn'] >= 7.5) & (df['fft_sn'] < 8.0) & (df['nh'] > 0) & (df['nh'] <= 4)
        c4 = (df['period'] > 0.1) & (df['period'] <= 0.2) & (df['fft_sn'] >= 7.0) & (df['fft_sn'] < 8.0) & (df['nh'] >= 2)
        c5 = (df['period'] > 0.2) & (df['fft_sn'] >= 7.0) & (df['fft_sn'] < 7.5) & (df['nh'] >= 2)
        c6 = (df['period'] >= 0.3) & (df['fft_sn'] >= 6.0) & (df['fft_sn'] <= 7.0) & (df['nh'] >= 3)
        c7 = (df['period'] >= 0.5) & (df['fft_sn'] >= 5.5) & (df['fft_sn'] <= 6.0) & (df['nh'] >= 3)
        c8 = (df['period'] >= 1.0) & (df['fft_sn'] >= 5.0) & (df['fft_sn'] < 5.5) & (df['nh'] >= 3)
        return df[c1 | c2 | c3 | c4 | c5 | c6 | c7 | c8]
    except Exception as e:
        print("Error during candidate filtering:", e)
        return pd.DataFrame()


# Output helpers

def save_candidate_list(df, chunk_id, outdir=".", prefix="candidates"):
    os.makedirs(outdir, exist_ok=True)
    outfile = os.path.join(outdir, f"{prefix}_{chunk_id}.txt")
    df.to_csv(outfile, sep=" ", index=False)
    print(f"Saved: {outfile}")


def write_zap_file(final_freqs, chunk_id, T=25.6, outdir="."):
    df_res = 1 / T
    width = 2 * df_res
    os.makedirs(outdir, exist_ok=True)
    outfile = os.path.join(outdir, f"birdies_{chunk_id}.zap")
    with open(outfile, "w") as f:
        f.write("#Frequency Width\n")
        for freq in final_freqs:
            f.write(f"{freq:.6f} {width:.6f}\n")
        f.write("5086.263020833333   1.07\n")
    print(f"Zap file written: {outfile}")


# Per-beam fold input export

def export_per_beam_fold_inputs(
    df_final,
    chunk_id,
    tshift="12.8",
    t_window="25.6",
    pipeline_script="fold_pipeline_v3.py",
    outdir=".",
    commands_file="fold_commands.sh",
):
    os.makedirs(outdir, exist_ok=True)

    required_cols = [
        "cand_no", "period", "acc", "dm", "nh", "fft_sn",
        "beam", "window", "start_sec", "T_window", "filterbank"
    ]
    missing = [c for c in required_cols if c not in df_final.columns]
    if missing:
        raise ValueError(f"Sifted DataFrame is missing columns: {missing}")

    beam_paths = {}

    with open(commands_file, "a") as cf:
        for beam_num, df_beam in df_final.groupby("beam"):
            beam_num = int(beam_num)

            fil_paths = df_beam["filterbank"].dropna().unique()
            if len(fil_paths) == 0:
                print(f"[WARN] Beam {beam_num}: no filterbank path found, skipping.")
                continue
            if len(fil_paths) > 1:
                print(f"[WARN] Beam {beam_num}: multiple filterbank paths, using first: {fil_paths[0]}")
            fil_path = fil_paths[0]

            fil_stem = os.path.splitext(os.path.basename(fil_path))[0]
            prefix = f"{fil_stem}_beam{beam_num:02d}_chunk{int(chunk_id):04d}"

            csv_name = f"candidates_beam_{beam_num:02d}_chunk{int(chunk_id):04d}.csv"
            csv_path = os.path.join(outdir, csv_name)

            df_out = df_beam.copy().reset_index(drop=True)
            df_out["cand_no"] = df_out.index + 1
            df_out.to_csv(csv_path, index=False)
            beam_paths[beam_num] = csv_path

            print(f"[Beam {beam_num:02d}] Wrote {len(df_out)} candidates -> {csv_path}")

            outdir_fold = os.path.join(outdir,
                "fold_results", fil_stem, f"beam{beam_num:02d}", f"chunk{int(chunk_id):04d}"
            )
            os.makedirs(outdir_fold, exist_ok=True)

            cmd = (
                f"python {pipeline_script} "
                f"--fil_file_path {fil_path} "
                f"--cands {csv_path} "
                f"--tshift {tshift} "
                f"--twindow {t_window} "
                f"--prefix {prefix} "
                f"--outdir {outdir_fold}"
            )
            cf.write(cmd + "\n")

    print(f"Folding commands appended to: {commands_file}")
    return beam_paths


# Chunk processor

def process_chunk(base_path, chunk_id, nbeams=19, outdir=".", commands_file="fold_commands.sh",
                  det_t=25.6, dec_deg=33., t_win=25.6, stride=12.8,
                  birdie_sn_min=10, birdie_dm_max=500):
    print(f"\n{'='*50}")
    print(f"Processing chunk: {chunk_id}")
    print(f"{'='*50}")

    df_all = load_beams_for_chunk(base_path, chunk_id, nbeams=nbeams)
    if df_all.empty:
        print(f"No data loaded for chunk {chunk_id}.")
        return None

    save_candidate_list(df_all, chunk_id, outdir=outdir, prefix="raw_candidates")

    # --- multibeam birdie finder ---
    final, why, bw, wb = find_birdies(
        df_all, sn_min=birdie_sn_min, dm_max=birdie_dm_max,
        T_win=t_win, stride=stride, dec_deg=dec_deg,
    )
    birdie_freqs = sorted(why.index) if not why.empty else []

    print("\n--- Identified Birdies ---")
    if birdie_freqs:
        birdie_table = final[final.rfi_rep].set_index("freq_bin").join(why)
        print(birdie_table[["fft_sn", "beam", "window",
                            "window_persist", "all_beams", "separation"]]
              .sort_values("fft_sn", ascending=False))
        os.makedirs(outdir, exist_ok=True)
        birdie_table.to_csv(os.path.join(outdir, f"birdies_{chunk_id}.csv"))
        write_zap_file(birdie_freqs, chunk_id, T=det_t, outdir=outdir)
    else:
        print("None found.")

    # --- candidate filtering + birdie removal ---
    df_candidates = create_filtered_cands(df_all).copy()
    df_candidates["freq_bin"] = (1.0 / df_candidates["period"]).round(FREQ_DECIMALS)

    df_clean = df_candidates[~df_candidates["freq_bin"].isin(birdie_freqs)].copy()
    df_final = df_clean.copy()     # no further RFI filter for now

    save_candidate_list(df_final, chunk_id, outdir=outdir, prefix="sifted_candidates")

    fold_input_dir = os.path.join(outdir, "fold_inputs")
    export_per_beam_fold_inputs(
        df_final, chunk_id,
        outdir=fold_input_dir,
        commands_file=commands_file,
    )

    print(f"\nTotal raw candidates            : {len(df_all)}")
    print(f"Birdie frequencies found        : {len(birdie_freqs)}")
    print(f"After period and nh filtering   : {len(df_candidates)}")
    print(f"After birdie removal            : {len(df_clean)}")
    print(f"Candidates ready for folding    : {len(df_final)}")

    birdies = dict(why=why, bw=bw, wb=wb)
    return df_candidates, df_clean, df_final, birdies


def process_all_chunks(base_path, nbeams=19, outdir=".", commands_file="fold_commands.sh",
                       det_t=25.6, dec_deg=33., t_win=25.6, stride=12.8,
                       birdie_sn_min=10, birdie_dm_max=500):
    os.makedirs(outdir, exist_ok=True)
    chunk_ids = discover_all_chunks(base_path, nbeams=nbeams)

    if not chunk_ids:
        print("No chunks found.")
        return

    print(f"Found {len(chunk_ids)} chunks: {chunk_ids}")

    results = {}
    for chunk_id in chunk_ids:
        result = process_chunk(
            base_path, chunk_id,
            nbeams=nbeams, outdir=outdir,
            commands_file=commands_file,
            det_t=det_t, dec_deg=dec_deg, t_win=t_win, stride=stride,
            birdie_sn_min=birdie_sn_min, birdie_dm_max=birdie_dm_max,
        )
        if result is not None:
            results[chunk_id] = result

    print(f"\nDone. Processed {len(results)}/{len(chunk_ids)} chunks successfully.")
    return results


# Entry point

def main():
    parser = argparse.ArgumentParser(
        description="Sift FFT pulsar candidates across all beams and chunks."
    )
    parser.add_argument(
        "--base_path", required=True,
        help="Path to the epoch directory containing per-beam subdirectories "
             "(e.g. /scratch-meerkat/crafts_processing/.../20220111)"
    )
    parser.add_argument(
        "--outdir", required=True,
        help="Directory where output candidate lists and fold inputs are written."
    )
    parser.add_argument(
        "--epoch", required=True,
        help="Epoch label used to name the fold commands file (e.g. 20220111)."
    )
    parser.add_argument(
        "--nbeams", type=int, default=19,
        help="Number of beams to process (default: 19)."
    )
    parser.add_argument(
        "--det_t", type=float, default=25.6,
        help="Observation length T (s) used for the zap-file width (2/T)."
    )
    parser.add_argument(
        "--dec_deg", type=float, default=33.0,
        help="Declination of the drift scan [deg]; sets the drift rate used by "
             "the birdie finder's window-persistence and beam-separation cuts."
    )
    parser.add_argument(
        "--t_win", type=float, default=25.6,
        help="Window length [s] used by the birdie finder."
    )
    parser.add_argument(
        "--stride", type=float, default=12.8,
        help="Window stride [s] used by the birdie finder."
    )
    parser.add_argument(
        "--birdie_sn_min", type=float, default=10.0,
        help="Only candidates with fft_sn above this are used to find birdies."
    )
    parser.add_argument(
        "--birdie_dm_max", type=float, default=500.0,
        help="Only candidates with DM up to this are used to find birdies."
    )
    args = parser.parse_args()

    commands_file = os.path.join(args.outdir, f"fold_commands_{args.epoch}.sh")

    process_all_chunks(
        base_path=args.base_path,
        nbeams=args.nbeams,
        outdir=args.outdir,
        commands_file=commands_file,
        det_t=args.det_t,
        dec_deg=args.dec_deg,
        t_win=args.t_win,
        stride=args.stride,
        birdie_sn_min=args.birdie_sn_min,
        birdie_dm_max=args.birdie_dm_max,
    )


if __name__ == "__main__":
    main()