# CRAFTS reprocessing: everything for one run

Unpack this inside `/aphid/temp/fast_crafts/crafts_processing/`, so that the paths in
`automation/crafts_config.ini` are right as shipped:

```
crafts_processing/crafts_pipeline/
  automation/          the automation (runs on the cluster)
    crafts.py            plan / run / status / show / rerun-failed / timing / set-aside / report / sync-cmd
    crafts_config.ini    ONE config: paths, science parameters, SLURM settings per step
    crafts_feeder.sh     keeps N epochs in progress from a queue file
    queue_new_epochs.txt the 34 never-processed clean epochs, in batch order
    steps/               one sbatch wrapper per step + check job (calls the scripts below)
    README.md            full automation manual (commands, states, set-aside, packing, partitions)
  scripts/             the science scripts, all in one folder (unchanged copies)
    update_pointings_v2.py            step 1  fix beam positions in raw FITS headers from *_pos.fits
    (digifil)                         step 2  PSRCHIVE/DSPSR binary, no script
    clean_filterbank.py               step 3  rfifind + channel mask -> _masked.fil
    run_sliding_search_for_birdies.py step 4  GPU sliding FFT, DM 0-5       (imports peasoup_runner.py)
    peasoup_runner.py
    make_zap_list.py                  step 5  multibeam birdies -> birdie_lists/birdies_CCCC.zap
    run_sliding_search_test_z.py      step 6  GPU sliding FFT, DM 5-500 + zap (imports peasoup_runner_test_z.py)
    peasoup_runner_test_z.py          *** NOT INCLUDED - copy it in (see below) ***
    prepare_candidates_to_fold_v3.py  step 7  multibeam birdie finder (Chen+2025 beams), sifting, fold commands
    fold_pipeline.py                  step 8  dspsr fold, clfd, pdmp_fwp, refold, 0-DM pdmp with fixed width
  audit/               standalone checks (read-only)
    audit_simple.py           file counts, beams, pos files, best chunk size per epoch
    audit_raw.py              header-level audit: time gaps, truncated files (+ run_audit.sbatch)
    audit_processed.py        what an (old) processed epoch contains, stage by stage
    check_pointing_updated.py were the raw headers already position-corrected?
  viewer/              for your laptop
    crafts_candidate_viewer_v2.py
```

## Install
```bash
cd /aphid/temp/fast_crafts/crafts_processing
tar xzf crafts_pipeline.tar.gz
cp <where it is>/peasoup_runner_test_z.py crafts_pipeline/scripts/     # the one missing file
cd crafts_pipeline/automation
alias crafts="python3 $PWD/crafts.py -c $PWD/crafts_config.ini"        # also put this in ~/.bashrc
crafts status
```
Dec+3135, which is already running, uses the old automation folder and keeps going. Epochs
started from here use this folder. Both use the same `proc_root`, so `crafts status` from either
one shows every epoch.

## Notes
* The science scripts are **unchanged copies**: `update_pointings_v2.py`, `clean_filterbank.py`,
  the birdie and search scripts, `peasoup_runner.py` and `make_zap_list.py` come from your
  notebook; `prepare_candidates_to_fold_v3.py` and `fold_pipeline.py` are the versions you sent
  last.
* `fold_pipeline.py` calls `/fred/oz002/users/vmandaog/pdmp_dev/pdmp_fwp` at that full path, as
  requested.
* The fold commands written by `prepare_candidates_to_fold_v3.py` name `fold_pipeline_v3.py`.
  The fold wrapper swaps that for `fold_script` from the config (`scripts/fold_pipeline.py`),
  and the swap is printed in each fold task's log.
* `--dec_deg` for the birdie finder in step 7 is worked out from each pointing's name
  (Dec+3135_01_05 -> 31.5833).
* Known issues in the science scripts, not changed here: in `fold_pipeline.py` pdmp runs twice in
  the first pass, the 0-DM `-fw` pdmp has no `-mc 32`, and the final `rm *.txt` deletes
  `*_nearby_pulsars.txt`. Both `make_zap_list.py` and the prepare script find chunks from beam 01
  only; the automation creates M01 placeholder folders for set-aside chunks.
* The audit tools take the config with `-c ../automation/crafts_config.ini`.
