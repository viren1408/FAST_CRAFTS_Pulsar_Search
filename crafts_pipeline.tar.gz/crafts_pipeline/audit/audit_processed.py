#!/usr/bin/env python3
"""
audit_processed.py - READ-ONLY audit of epochs that were processed before the
automation (old runs), or by it. Nothing is changed, moved or deleted.

For every epoch folder  <proc_root>/<project>/<pointing>/<date>/  it counts, per
stage, what exists for every beam x chunk:

  fil       NN/<prefix>-MNN_CCCC.fil
  masked    NN/<prefix>-MNN_CCCC_masked.fil   (+ rfi_masks/<stem>_peasoup.kill)
  birdies   NN/<stem>_masked_birdies/          (csv present or not)
  zap       birdie_lists/birdies_CCCC.zap      (per chunk)
  search    NN/<stem>_masked_candidates/       (csv present or not)
  fold_cmds fold_commands*.sh lines             (in any sifting_output* folder)
  folded    sorted.cands under fold_results     (per beam x chunk)

and reports the furthest stage that is complete for all beams x chunks, plus a
list of what is missing at each stage.

Optional: --gaps audit_gaps.csv (from audit_raw.py, which reads the raw FITS
headers) maps raw-data time gaps / missing files onto the old chunks
(--old-files-per-chunk, default 19) so you know which old beam x chunks were
stitched across a gap by digifil -cont and whose candidates are suspect.

Usage
  python3 audit_processed.py --proc-root /aphid/temp/fast_crafts/crafts_processing \
      --project ZD2021_1_1_2bit -o /fred/.../audit_processed
  python3 audit_processed.py ... --only Dec+2045_01_05,Dec+2715_01_05 --gaps /fred/.../audit_raw/audit_gaps.csv
"""

import argparse
import csv
import glob
import os
import re
import statistics
import sys
from collections import defaultdict

STEM_RX = re.compile(r"^(?P<prefix>.+)-M(?P<beam>\d{2})_(?P<chunk>\d{4})(?P<rest>.*)$")
STAGES = ["fil", "masked", "birdies", "search", "folded"]


def scan_beam_dir(d):
    """Return dict kind -> {chunk: info} for one beam folder (scandir only, fast)."""
    out = {"fil": {}, "masked": {}, "birdies": {}, "search": {}}
    try:
        it = list(os.scandir(d))
    except OSError:
        return out, None
    prefix = None
    for e in it:
        m = STEM_RX.match(e.name)
        if not m:
            continue
        prefix = prefix or m.group("prefix")
        c, rest = int(m.group("chunk")), m.group("rest")
        if rest == ".fil" and e.is_file():
            out["fil"][c] = e.stat().st_size
        elif rest == "_masked.fil" and e.is_file():
            out["masked"][c] = e.stat().st_size
        elif rest == "_masked_birdies" and e.is_dir():
            out["birdies"][c] = os.path.exists(os.path.join(e.path, "candidates_with_beam.csv"))
        elif rest == "_masked_candidates" and e.is_dir():
            out["search"][c] = os.path.exists(os.path.join(e.path, "candidates_with_beam.csv"))
    return out, prefix


def find_sifting_dirs(proc_root, project, pointing, edir):
    cands = [os.path.join(edir, "sifting_output")]
    cands += glob.glob(os.path.join(edir, "sifting_output*"))
    cands += glob.glob(os.path.join(proc_root, f"sifting_output_{pointing}*"))
    cands += glob.glob(os.path.join(proc_root, project, pointing, f"sifting_output*"))
    seen, out = set(), []
    for c in cands:
        if os.path.isdir(c) and os.path.realpath(c) not in seen:
            seen.add(os.path.realpath(c))
            out.append(c)
    return out


def folded_set(sift_dirs):
    """beam x chunk pairs with a sorted.cands (old layout fold_results/<stem>/beamNN/chunkCCCC
    or new layout fold_results/beamNN/chunkCCCC), plus counts."""
    got, n_png, n_rows = set(), 0, 0
    for sd in sift_dirs:
        for sc in glob.glob(os.path.join(sd, "**", "sorted.cands"), recursive=True):
            mb = re.search(r"beam(\d{2})", sc)
            mc = re.search(r"chunk(\d{4})", sc)
            if mb and mc:
                got.add((int(mb.group(1)), int(mc.group(1))))
            try:
                n_rows += max(0, sum(1 for _ in open(sc)) - 1)
            except OSError:
                pass
            n_png += len(glob.glob(os.path.join(os.path.dirname(sc), "*.png")))
    return got, n_png, n_rows


def fold_cmd_count(sift_dirs):
    n, files = 0, []
    for sd in sift_dirs:
        for f in glob.glob(os.path.join(sd, "fold_commands*.sh")):
            files.append(f)
            with open(f, errors="replace") as fh:
                n += sum(1 for ln in fh if ln.strip() and not ln.startswith("#"))
    return n, files


def load_gaps(path, old_k):
    """audit_gaps.csv from audit_raw.py -> {(pointing, epoch, beam): [(after_idx, next_idx, type, gap_s)]}"""
    g = defaultdict(list)
    if not path:
        return g
    for r in csv.DictReader(open(path)):
        # obs_id = <pointing>__<epoch>[__<prefix>]
        parts = r["obs_id"].split("__")
        g[(parts[0], parts[1], int(r["beam"].lstrip("M")))].append(
            (int(r["after_idx"]), int(r["next_idx"]), r["type"], r.get("gap_s", "")))
    return g


def audit_epoch(proc_root, project, pointing, epoch, nbeams, gaps, old_k):
    edir = os.path.join(proc_root, project, pointing, epoch)
    beams = {}
    prefix = None
    for b in range(1, nbeams + 1):
        d, p = scan_beam_dir(os.path.join(edir, f"{b:02d}"))
        beams[b] = d
        prefix = prefix or p
    all_chunks = sorted({c for b in beams.values() for c in b["fil"]} |
                        {c for b in beams.values() for c in b["masked"]})
    n_chunks = (max(all_chunks) + 1) if all_chunks else 0
    expected = {(b, c) for b in range(1, nbeams + 1) for c in range(n_chunks)}
    have = {k: {(b, c) for b in beams for c in beams[b][k]} for k in ("fil", "masked", "birdies", "search")}
    with_csv = {k: {(b, c) for b in beams for c, ok in beams[b][k].items() if ok} for k in ("birdies", "search")}
    zaps = {int(m.group(1)) for f in glob.glob(os.path.join(edir, "birdie_lists", "birdies_*.zap"))
            for m in [re.search(r"birdies_(\d+)\.zap$", f)] if m}
    kills = len(glob.glob(os.path.join(edir, "rfi_masks", "*_peasoup.kill")))
    sift = find_sifting_dirs(proc_root, project, pointing, edir)
    folded, n_png, n_rows = folded_set(sift)
    n_cmds, cmd_files = fold_cmd_count(sift)
    have["folded"] = folded

    # odd-sized filterbanks (other than the last chunk) = possibly truncated
    sizes = [s for b in beams.values() for c, s in b["fil"].items() if c != n_chunks - 1]
    med = statistics.median(sizes) if sizes else 0
    small = sorted((b, c) for b in beams for c, s in beams[b]["fil"].items()
                   if c != n_chunks - 1 and med and s < 0.98 * med)

    furthest = "none"
    for st in STAGES:
        if st == "folded":
            # fold only runs where sifting left candidates, so compare with the commands
            if n_cmds and len(folded) >= n_cmds:
                furthest = "folded"
            continue
        if expected and expected <= have[st]:
            furthest = st
        else:
            break
    if furthest == "search" and n_cmds:
        furthest = "fold_cmds" if len(folded) < n_cmds else "folded"

    missing = []
    for st in ("fil", "masked", "birdies", "search"):
        for bc in sorted(expected - have[st]):
            missing.append((st, *bc))
    for bc in small:
        missing.append(("fil_small", *bc))

    # map raw gaps onto old chunks
    suspect = []
    for b in range(1, nbeams + 1):
        for (after, nxt, typ, gap_s) in gaps.get((pointing, epoch, b), []):
            c_after, c_next = (after - 1) // old_k, (nxt - 1) // old_k
            if c_after == c_next or typ == "missing_index":
                suspect.append((b, c_after, typ, after, nxt, gap_s))

    return {
        "project": project, "pointing": pointing, "epoch": epoch, "prefix": prefix or "",
        "managed_by_crafts": os.path.isdir(os.path.join(edir, "pipeline")),
        "n_chunks": n_chunks, "expected_beam_chunks": len(expected),
        "fil": len(have["fil"]), "masked": len(have["masked"]), "kill_files": kills,
        "birdies_dirs": len(have["birdies"]), "birdies_csv": len(with_csv["birdies"]),
        "zap_files": len(zaps), "search_dirs": len(have["search"]), "search_csv": len(with_csv["search"]),
        "fold_commands": n_cmds, "folded": len(folded), "sorted_cands_rows": n_rows, "pngs": n_png,
        "small_fil": len(small), "furthest_complete": furthest,
        "sifting_dirs": ";".join(sift), "suspect_old_chunks": len(suspect),
    }, missing, suspect


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--proc-root", default="/aphid/temp/fast_crafts/crafts_processing")
    ap.add_argument("--project", action="append", default=None,
                    help="project folder(s), default ZD2020_1_1_2bit and ZD2021_1_1_2bit")
    ap.add_argument("--only", default="", help="comma-separated pointings")
    ap.add_argument("--nbeams", type=int, default=19)
    ap.add_argument("--gaps", help="audit_gaps.csv from audit_raw.py (raw-data gaps)")
    ap.add_argument("--old-files-per-chunk", type=int, default=19)
    ap.add_argument("-o", "--outdir", required=True)
    a = ap.parse_args()
    projects = a.project or ["ZD2020_1_1_2bit", "ZD2021_1_1_2bit"]
    only = {s.strip() for s in a.only.split(",") if s.strip()}
    if os.path.realpath(a.outdir).startswith(os.path.realpath(a.proc_root) + os.sep):
        print("note: writing the report inside proc_root")
    os.makedirs(a.outdir, exist_ok=True)
    gaps = load_gaps(a.gaps, a.old_files_per_chunk)

    rows, miss_rows, sus_rows = [], [], []
    for proj in projects:
        pdir = os.path.join(a.proc_root, proj)
        if not os.path.isdir(pdir):
            continue
        for pointing in sorted(os.listdir(pdir)):
            if only and pointing not in only:
                continue
            for epoch in sorted(os.listdir(os.path.join(pdir, pointing))):
                edir = os.path.join(pdir, pointing, epoch)
                if not (os.path.isdir(edir) and os.path.isdir(os.path.join(edir, "01"))):
                    continue
                r, miss, sus = audit_epoch(a.proc_root, proj, pointing, epoch, a.nbeams, gaps, a.old_files_per_chunk)
                rows.append(r)
                miss_rows += [[pointing, epoch, *m] for m in miss]
                sus_rows += [[pointing, epoch, *s] for s in sus]
                print(f"  {pointing:<22}{epoch:<10} {r['furthest_complete']:<10} "
                      f"fil {r['fil']}/{r['expected_beam_chunks']}  folded {r['folded']}/{r['fold_commands']}", flush=True)

    with open(os.path.join(a.outdir, "processed_epochs.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()) if rows else ["none"])
        w.writeheader()
        w.writerows(rows)
    with open(os.path.join(a.outdir, "processed_missing.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["pointing", "epoch", "stage_missing", "beam", "chunk"])
        w.writerows(miss_rows)
    with open(os.path.join(a.outdir, "processed_suspect_chunks.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["pointing", "epoch", "beam", "old_chunk", "problem", "file_after", "file_next", "gap_s"])
        w.writerows(sus_rows)

    L = [f"{'pointing':<22}{'epoch':<10}{'crafts':>7}{'chunks':>7}{'fil':>7}{'masked':>7}{'bird':>6}"
         f"{'zap':>5}{'search':>7}{'cmds':>6}{'folded':>7}{'rows':>7}{'small':>6}{'suspect':>8}  furthest complete"]
    for r in rows:
        L.append(f"{r['pointing']:<22}{r['epoch']:<10}{'yes' if r['managed_by_crafts'] else '-':>7}{r['n_chunks']:>7}"
                 f"{r['fil']:>7}{r['masked']:>7}{r['birdies_dirs']:>6}{r['zap_files']:>5}{r['search_dirs']:>7}"
                 f"{r['fold_commands']:>6}{r['folded']:>7}{r['sorted_cands_rows']:>7}{r['small_fil']:>6}"
                 f"{(r['suspect_old_chunks'] if a.gaps else '-')!s:>8}  {r['furthest_complete']}")
    L += ["", "counts are beam x chunks (expected = 19 x chunks); zap = per chunk; cmds = fold command lines;",
          "folded = beam x chunks with sorted.cands; rows = candidate rows in all sorted.cands;",
          "small = .fil smaller than typical (not last chunk) - possibly truncated;",
          "suspect = old beam x chunks containing a raw gap / missing file (needs --gaps).",
          "details: processed_missing.csv, processed_suspect_chunks.csv"]
    txt = "\n".join(L)
    open(os.path.join(a.outdir, "processed_summary.txt"), "w").write(txt + "\n")
    print("\n" + txt)


if __name__ == "__main__":
    main()
