#!/usr/bin/env python3
"""
CRAFTS reprocessing - Step 0: audit of the raw FAST PSRFITS data.

What it does
------------
1. Walks every project directory (ZD2020_1_1_2bit, ZD2021_1_1_2bit, ...) under
   raw_root, finds every *.fits file and groups them into observations:
       (project, pointing, epoch sub-directory, filename prefix)
   Extra epochs nested inside a pointing directory, and several observations on
   the same date, are kept as separate observations.
2. Reads the PSRFITS headers (in parallel) for start time, file duration,
   sampling, channels, bits, and checks for truncated or unreadable files.
3. Checks per beam: missing file indices, time gaps between consecutive files.
   Checks across beams: missing beams, indices not present in all 19 beams.
4. Matches each observation to its *_pos.fits file (so you know what can be
   processed now) and lists pos files that have no raw data.
5. Picks the files-per-chunk for digifil per observation (close to the target
   chunk length, as little data thrown away as possible) and only ever chunks
   inside contiguous runs. Writes a chunk plan per observation.

Outputs (in audit_dir)
----------------------
    audit_summary.txt         human-readable high-level report
    audit_status.json         machine-readable status for the next pipeline step
    audit_observations.csv    one row per observation (epoch)
    audit_files.csv           one row per raw file (also used as a cache by --resume)
    audit_gaps.csv            every discontinuity found
    chunk_plans/<obs_id>.json per-observation chunk plan (file lists per beam)
    audit.log                 log

Usage
-----
    python audit_raw.py -c crafts_config.ini            # full audit
    python audit_raw.py -c crafts_config.ini --resume   # reuse headers already read
    python audit_raw.py -c crafts_config.ini --only Dec+2002_01_05,Dec-0536_04_05
"""

import argparse
import configparser
import csv
import datetime as dt
import json
import logging
import math
import os
import re
import statistics
import sys
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed

LOG = logging.getLogger("crafts_audit")
MJD_UNIX0 = 40587.0  # MJD of 1970-01-01

FILE_FIELDS = [
    "obs_id", "project", "pointing", "epoch_dir", "prefix", "beam", "idx", "path",
    "size_bytes", "mtime", "header_read", "ok", "error", "truncated",
    "start_mjd", "duration_s", "tbin_s", "nsblk", "nsubint", "nchan", "nbits",
    "npol", "obsfreq_mhz", "obsbw_mhz", "ra", "dec", "src_name",
]


# ----------------------------------------------------------------------------
# config / logging
# ----------------------------------------------------------------------------
def load_config(path):
    cp = configparser.ConfigParser(interpolation=None)
    if not cp.read(path):
        sys.exit(f"Cannot read config {path}")
    p, a = cp["paths"], cp["audit"]
    cfg = {
        "raw_root": p.get("raw_root"),
        "raw_projects": [s.strip() for s in p.get("raw_projects").split(",") if s.strip()],
        "pos_dir": p.get("pos_dir"),
        "audit_dir": p.get("audit_dir"),
        "file_regex": a.get("file_regex"),
        "pos_regex": a.get("pos_regex"),
        "n_beams": a.getint("n_beams", 19),
        "header_beams": a.get("header_beams", "all").strip(),
        "n_workers": a.getint("n_workers", 8),
        "contig_tol_s": a.getfloat("contig_tol_s", 0.1),
        "target_chunk_s": a.getfloat("target_chunk_s", 245.0),
        "min_files_per_chunk": a.getint("min_files_per_chunk", 0),
        "max_files_per_chunk": a.getint("max_files_per_chunk", 0),
        "leftover_policy": a.get("leftover_policy", "own_chunk").strip(),
        "min_chunk_s": a.getfloat("min_chunk_s", 60.0),
    }
    if cfg["leftover_policy"] not in ("drop", "own_chunk", "extend_last"):
        sys.exit(f"Bad leftover_policy {cfg['leftover_policy']}")
    hb = cfg["header_beams"].lower()
    cfg["header_beam_set"] = None if hb == "all" else {int(x) for x in hb.split(",")}
    return cfg


def setup_logging(audit_dir):
    os.makedirs(audit_dir, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%Y-%m-%d %H:%M:%S")
    LOG.setLevel(logging.INFO)
    for h in (logging.FileHandler(os.path.join(audit_dir, "audit.log"), mode="w"),
              logging.StreamHandler(sys.stdout)):
        h.setFormatter(fmt)
        LOG.addHandler(h)


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def mjd_to_datetime(mjd):
    return dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc) + dt.timedelta(days=mjd - MJD_UNIX0)


def fmt_mjd(mjd):
    if mjd is None or (isinstance(mjd, float) and math.isnan(mjd)):
        return ""
    return mjd_to_datetime(mjd).strftime("%Y-%m-%d %H:%M:%S")


def to_float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def human_bytes(n):
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(n) < 1024 or unit == "PB":
            return f"{n:.2f} {unit}"
        n /= 1024.0


def obs_identifier(pointing, epoch_dir, prefix):
    tag = epoch_dir.replace(os.sep, "-") if epoch_dir else "nodate"
    pre = prefix
    if pre.startswith(pointing):
        pre = pre[len(pointing):].lstrip("_-")
    return f"{pointing}__{tag}" + (f"__{pre}" if pre else "")


# ----------------------------------------------------------------------------
# discovery
# ----------------------------------------------------------------------------
def discover(cfg, only=None):
    """Return list of file dicts (no header info yet) and list of unparsed paths."""
    rx = re.compile(cfg["file_regex"])
    files, unparsed = [], []
    for project in cfg["raw_projects"]:
        proj_dir = os.path.join(cfg["raw_root"], project)
        if not os.path.isdir(proj_dir):
            LOG.warning("Project directory missing: %s", proj_dir)
            continue
        for pointing in sorted(os.listdir(proj_dir)):
            pdir = os.path.join(proj_dir, pointing)
            if not os.path.isdir(pdir):
                continue
            if only and pointing not in only:
                continue
            n_before = len(files)
            for root, dirs, fnames in os.walk(pdir):
                dirs.sort()
                fits = [f for f in fnames if f.endswith(".fits")]
                if not fits:
                    continue
                epoch_dir = os.path.relpath(root, pdir)
                epoch_dir = "" if epoch_dir == "." else epoch_dir
                for fn in sorted(fits):
                    path = os.path.join(root, fn)
                    m = rx.match(fn)
                    if not m:
                        unparsed.append(path)
                        continue
                    try:
                        st = os.stat(path)
                        size, mtime = st.st_size, int(st.st_mtime)
                    except OSError:
                        size, mtime = -1, 0
                    files.append({
                        "project": project, "pointing": pointing, "epoch_dir": epoch_dir,
                        "prefix": m.group("prefix"), "beam": int(m.group("beam")),
                        "idx": int(m.group("idx")), "path": path,
                        "size_bytes": size, "mtime": mtime,
                    })
            LOG.info("  %-12s %-22s %6d fits", project, pointing, len(files) - n_before)
    for f in files:
        f["obs_id"] = obs_identifier(f["pointing"], f["epoch_dir"], f["prefix"])
    return files, unparsed


# ----------------------------------------------------------------------------
# header reading
# ----------------------------------------------------------------------------
def read_psrfits_header(path):
    """Read just enough of a PSRFITS search-mode file. Runs in worker processes."""
    out = {"header_read": 1, "ok": 0, "error": "", "truncated": 0}
    try:
        from astropy.io import fits
        import warnings
        warnings.simplefilter("ignore")
        with fits.open(path, memmap=True, lazy_load_hdus=True, ignore_missing_end=True) as hd:
            h0 = hd[0].header
            sub = None
            for i, h in enumerate(hd):
                if h.name == "SUBINT":
                    sub = i
                    break
            if sub is None:
                out["error"] = "no SUBINT HDU"
                return out
            h1 = hd[sub].header
            nrows = int(h1.get("NAXIS2", 0))
            nsblk = int(h1.get("NSBLK", 0))
            tbin = float(h1.get("TBIN", 0.0))
            out.update({
                "nsubint": nrows, "nsblk": nsblk, "tbin_s": tbin,
                "nchan": int(h1.get("NCHAN", h0.get("OBSNCHAN", 0))),
                "nbits": int(h1.get("NBITS", 0)), "npol": int(h1.get("NPOL", 0)),
                "obsfreq_mhz": float(h0.get("OBSFREQ", float("nan"))),
                "obsbw_mhz": float(h0.get("OBSBW", float("nan"))),
                "ra": str(h0.get("RA", "")), "dec": str(h0.get("DEC", "")),
                "src_name": str(h0.get("SRC_NAME", "")),
            })
            # truncation check: data start + table size + heap vs file size
            info = hd.fileinfo(sub)
            expected = info["datLoc"] + int(h1.get("NAXIS1", 0)) * nrows + int(h1.get("PCOUNT", 0))
            if os.path.getsize(path) < expected:
                out["truncated"] = 1
                out["error"] = f"truncated: {os.path.getsize(path)} < {expected} bytes"
                return out
            stt = (int(h0.get("STT_IMJD", 0))
                   + (float(h0.get("STT_SMJD", 0)) + float(h0.get("STT_OFFS", 0.0))) / 86400.0)
            offset0 = 0.0
            try:
                data = hd[sub].data
                tsub0 = float(data["TSUBINT"][0])
                offset0 = float(data["OFFS_SUB"][0]) - tsub0 / 2.0
            except Exception:
                pass  # no OFFS_SUB column: assume file starts at STT
            out["start_mjd"] = stt + offset0 / 86400.0
            out["duration_s"] = nrows * nsblk * tbin
            if out["duration_s"] <= 0 or stt <= 0:
                out["error"] = "bad timing keywords"
                return out
            out["ok"] = 1
    except Exception as e:  # noqa: BLE001
        out["error"] = f"{type(e).__name__}: {e}"[:200]
    return out


def read_headers(files, cfg, cache):
    todo = []
    for f in files:
        key = f["path"]
        c = cache.get(key)
        if c and int(c.get("size_bytes", -2)) == f["size_bytes"] and int(c.get("mtime", -2)) == f["mtime"] \
                and c.get("header_read") == "1":
            for k in FILE_FIELDS:
                if k not in f and k in c:
                    f[k] = c[k]
            for k in ("ok", "truncated", "header_read", "nsblk", "nsubint", "nchan", "nbits", "npol"):
                f[k] = int(float(f[k])) if f.get(k) not in (None, "") else 0
            for k in ("start_mjd", "duration_s", "tbin_s", "obsfreq_mhz", "obsbw_mhz"):
                f[k] = to_float(f.get(k))
            continue
        hb = cfg["header_beam_set"]
        if hb is None or f["beam"] in hb:
            todo.append(f)
        else:
            f.update({"header_read": 0, "ok": 1 if f["size_bytes"] > 0 else 0, "error": "", "truncated": 0})
    LOG.info("Header reads: %d to read, %d from cache", len(todo), len(files) - len(todo)
             - sum(1 for f in files if f.get("header_read") == 0))
    if not todo:
        return
    t0, done = time.time(), 0
    with ProcessPoolExecutor(max_workers=cfg["n_workers"]) as ex:
        futs = {ex.submit(read_psrfits_header, f["path"]): f for f in todo}
        for fut in as_completed(futs):
            f = futs[fut]
            try:
                f.update(fut.result())
            except Exception as e:  # noqa: BLE001
                f.update({"header_read": 1, "ok": 0, "error": f"worker: {e}"[:200], "truncated": 0})
            done += 1
            if done % 2000 == 0 or done == len(todo):
                el = time.time() - t0
                LOG.info("  headers %d/%d  (%.0f files/s)", done, len(todo), done / max(el, 1e-6))


def load_cache(audit_dir):
    path = os.path.join(audit_dir, "audit_files.csv")
    if not os.path.exists(path):
        return {}
    with open(path) as fh:
        return {r["path"]: r for r in csv.DictReader(fh)}


# ----------------------------------------------------------------------------
# per-observation analysis
# ----------------------------------------------------------------------------
def choose_chunking(runs_len, fdur, cfg):
    """Pick files-per-chunk minimising discarded data, tie-break closest to target."""
    tgt = cfg["target_chunk_s"]
    kmin = cfg["min_files_per_chunk"] or max(1, int(math.floor(0.75 * tgt / fdur)))
    kmax = cfg["max_files_per_chunk"] or max(kmin, int(math.ceil(1.25 * tgt / fdur)))
    best = None
    for k in range(kmin, kmax + 1):
        lost = 0
        for n in runs_len:
            r = n % k if n >= k else n
            if cfg["leftover_policy"] == "own_chunk" and r * fdur >= cfg["min_chunk_s"]:
                r = 0
            if cfg["leftover_policy"] == "extend_last" and n >= k:
                r = 0
            lost += r
        score = (lost, abs(k * fdur - tgt))
        if best is None or score < best[0]:
            best = (score, k)
    return best[1], kmin, kmax


def build_chunks(runs, k, fdur, cfg):
    """runs: list of lists of idx. Returns list of (run_id, [idx...]) and dropped idx."""
    chunks, dropped = [], []
    for rid, run in enumerate(runs):
        n = len(run)
        if n < k:
            if n * fdur >= cfg["min_chunk_s"] and cfg["leftover_policy"] != "drop":
                chunks.append((rid, run))
            else:
                dropped.extend(run)
            continue
        full = n // k
        parts = [run[i * k:(i + 1) * k] for i in range(full)]
        rest = run[full * k:]
        if rest:
            if cfg["leftover_policy"] == "extend_last":
                parts[-1] = parts[-1] + rest
            elif cfg["leftover_policy"] == "own_chunk" and len(rest) * fdur >= cfg["min_chunk_s"]:
                parts.append(rest)
            else:
                dropped.extend(rest)
        chunks.extend((rid, p) for p in parts)
    return chunks, dropped


def analyse_observation(obs_id, ofiles, cfg, gaps_out):
    nb = cfg["n_beams"]
    tol = cfg["contig_tol_s"]
    f0 = ofiles[0]
    res = {
        "obs_id": obs_id, "project": f0["project"], "pointing": f0["pointing"],
        "epoch_dir": f0["epoch_dir"], "prefix": f0["prefix"], "issues": [],
    }
    m = re.search(r"(\d{8})", f0["epoch_dir"] or "")
    res["epoch_date"] = m.group(1) if m else ""

    by_beam = defaultdict(dict)
    for f in ofiles:
        if f["idx"] in by_beam[f["beam"]]:
            res["issues"].append(f"duplicate file index M{f['beam']:02d}_{f['idx']:04d}")
        by_beam[f["beam"]][f["idx"]] = f
    beams = sorted(by_beam)
    expected = list(range(1, nb + 1))
    missing_beams = [b for b in expected if b not in by_beam]
    extra_beams = [b for b in beams if b not in expected]
    res["n_beams_present"] = len([b for b in beams if b in expected])
    res["missing_beams"] = ";".join(f"M{b:02d}" for b in missing_beams)
    if missing_beams:
        res["issues"].append(f"missing beams {res['missing_beams']}")
    if extra_beams:
        res["issues"].append(f"unexpected beams {extra_beams}")

    nper = [len(by_beam[b]) for b in beams if b in expected]
    res["files_per_beam_min"] = min(nper) if nper else 0
    res["files_per_beam_max"] = max(nper) if nper else 0
    res["n_files"] = len(ofiles)
    res["size_bytes"] = sum(max(f["size_bytes"], 0) for f in ofiles)

    # cheap integrity check for beams whose headers were not read: file size
    sizes = [f["size_bytes"] for f in ofiles if f["size_bytes"] > 0]
    med_size = statistics.median(sizes) if sizes else 0
    last_idx = {b: max(d) for b, d in by_beam.items()}
    n_small = 0
    for f in ofiles:
        if f["size_bytes"] < med_size and f["idx"] != last_idx[f["beam"]]:
            n_small += 1
            if not f["header_read"]:
                f["ok"], f["error"] = 0, f"size {f['size_bytes']} < typical {int(med_size)}"
    res["n_small_files"] = n_small
    if n_small:
        res["issues"].append(f"{n_small} files smaller than typical size (not last file)")

    bad = [f for f in ofiles if not f["ok"]]
    res["n_bad_files"] = len(bad)
    if bad:
        res["issues"].append(f"{len(bad)} unreadable/truncated files")

    hdr = [f for f in ofiles if f["header_read"] and f["ok"]]
    if not hdr:
        res["issues"].append("no readable headers")
        res.update({"processable": False, "chunks": [], "runs": []})
        return res

    def med(key):
        vals = [f[key] for f in hdr if f.get(key) not in (None, "")]
        return statistics.median(vals) if vals else None

    fdur = med("duration_s")
    res.update({
        "file_dur_s": fdur, "tbin_s": med("tbin_s"), "nchan": med("nchan"), "nbits": med("nbits"),
        "npol": med("npol"), "obsfreq_mhz": med("obsfreq_mhz"), "obsbw_mhz": med("obsbw_mhz"),
        "src_name": hdr[0].get("src_name", ""),
    })
    # header consistency across files
    for key in ("tbin_s", "nchan", "nbits", "nsblk"):
        vals = {round(float(f[key]), 12) for f in hdr if f.get(key) not in (None, "")}
        if len(vals) > 1:
            res["issues"].append(f"inconsistent {key}: {sorted(vals)}")
    odd = [f for f in hdr if abs(f["duration_s"] - fdur) > tol and f["idx"] != last_idx[f["beam"]]]
    if odd:
        res["issues"].append(f"{len(odd)} files with non-standard duration "
                             f"(e.g. M{odd[0]['beam']:02d}_{odd[0]['idx']:04d}: {odd[0]['duration_s']:.3f}s)")

    starts = [f["start_mjd"] for f in hdr]
    ends = [f["start_mjd"] + f["duration_s"] / 86400.0 for f in hdr]
    res["start_mjd"], res["end_mjd"] = min(starts), max(ends)
    res["start_utc"], res["end_utc"] = fmt_mjd(min(starts)), fmt_mjd(max(ends))
    res["span_s"] = (max(ends) - min(starts)) * 86400.0

    # ---- per-beam discontinuities
    breaks = set()  # boundary after idx i (between i and next index) is broken
    n_time_gaps = n_idx_gaps = 0
    max_abs_gap = 0.0
    for b in beams:
        idxs = sorted(by_beam[b])
        for i, j in zip(idxs[:-1], idxs[1:]):
            fi, fj = by_beam[b][i], by_beam[b][j]
            if j != i + 1:
                n_idx_gaps += 1
                gaps_out.append({"obs_id": obs_id, "beam": f"M{b:02d}", "after_idx": i, "next_idx": j,
                                 "type": "missing_index", "gap_s": "", "n_missing": j - i - 1})
            if fi["header_read"] and fj["header_read"] and fi["ok"] and fj["ok"]:
                gap = (fj["start_mjd"] - fi["start_mjd"]) * 86400.0 - fi["duration_s"]
                max_abs_gap = max(max_abs_gap, abs(gap))
                if abs(gap) > tol:
                    n_time_gaps += 1
                    breaks.add(i)
                    gaps_out.append({"obs_id": obs_id, "beam": f"M{b:02d}", "after_idx": i, "next_idx": j,
                                     "type": "time_gap" if gap > 0 else "time_overlap",
                                     "gap_s": f"{gap:.4f}", "n_missing": j - i - 1})
    res["n_index_gaps"] = n_idx_gaps
    res["n_time_gaps"] = n_time_gaps
    res["max_abs_gap_s"] = max_abs_gap
    if n_idx_gaps:
        res["issues"].append(f"{n_idx_gaps} missing-index gaps")
    if n_time_gaps:
        res["issues"].append(f"{n_time_gaps} time gaps > {tol}s")

    # ---- indices usable in all present expected beams
    use_beams = [b for b in expected if b in by_beam]
    common = None
    for b in use_beams:
        good = {i for i, f in by_beam[b].items() if f["ok"]}
        common = good if common is None else common & good
    common = sorted(common or [])
    all_idx = sorted({i for b in use_beams for i in by_beam[b]})
    partial = [i for i in all_idx if i not in set(common)]
    res["n_partial_idx"] = len(partial)
    if partial:
        res["issues"].append(f"{len(partial)} file indices not usable in every beam "
                             f"(e.g. {partial[:5]})")

    runs, cur = [], []
    for i in common:
        if cur and (i != cur[-1] + 1 or cur[-1] in breaks):
            runs.append(cur)
            cur = []
        cur.append(i)
    if cur:
        runs.append(cur)
    res["n_runs"] = len(runs)
    res["runs"] = [{"idx_start": r[0], "idx_end": r[-1], "n_files": len(r)} for r in runs]
    res["usable_files_per_beam"] = len(common)
    res["usable_time_s"] = len(common) * fdur
    res["contiguous"] = (len(runs) == 1 and not partial and n_time_gaps == 0 and n_idx_gaps == 0)

    # ---- chunk plan
    ref_beam = use_beams[0]
    k, kmin, kmax = choose_chunking([len(r) for r in runs], fdur, cfg)
    chunks, dropped = build_chunks(runs, k, fdur, cfg)
    res.update({"files_per_chunk": k, "k_range": f"{kmin}-{kmax}", "chunk_s": k * fdur,
                "n_chunks": len(chunks), "n_dropped_files": len(dropped),
                "dropped_s": len(dropped) * fdur})
    plan = []
    for cid, (rid, idxs) in enumerate(chunks):
        f_first = by_beam[ref_beam][idxs[0]]
        plan.append({
            "chunk": cid, "run": rid, "idx_start": idxs[0], "idx_end": idxs[-1], "n_files": len(idxs),
            "start_mjd": f_first.get("start_mjd"), "start_utc": fmt_mjd(f_first.get("start_mjd")),
            "duration_s": len(idxs) * fdur,
            "files": {f"M{b:02d}": [by_beam[b][i]["path"] for i in idxs] for b in use_beams},
        })
    res["chunks"] = plan
    res["processable_raw"] = len(chunks) > 0
    return res


# ----------------------------------------------------------------------------
# pos-file matching
# ----------------------------------------------------------------------------
def scan_pos(cfg):
    rx = re.compile(cfg["pos_regex"])
    pos = []
    if not os.path.isdir(cfg["pos_dir"]):
        LOG.warning("pos_dir missing: %s", cfg["pos_dir"])
        return pos
    for fn in sorted(os.listdir(cfg["pos_dir"])):
        m = rx.match(fn)
        if m:
            d = m.groupdict()
            pos.append({"file": fn, "path": os.path.join(cfg["pos_dir"], fn), "pointing": d["pointing"],
                        "date": d["date"], "hhmm": (d["hh"] + d["mm"]) if d.get("hh") else ""})
        elif fn.endswith(".fits"):
            LOG.warning("Unparsed pos file name: %s", fn)
    return pos


def match_pos(results, pos):
    """Attach pos_file to each observation. Returns list of unused pos files."""
    by_key = defaultdict(list)
    for p in pos:
        by_key[(p["pointing"], p["date"])].append(p)
    used = set()

    def dates_for(r):
        ds = []
        if r.get("epoch_date"):
            ds.append(r["epoch_date"])
        if r.get("start_mjd"):
            for off_h in (0, 8):  # UTC and Beijing time
                d = (mjd_to_datetime(r["start_mjd"]) + dt.timedelta(hours=off_h)).strftime("%Y%m%d")
                if d not in ds:
                    ds.append(d)
        return ds

    obs_by_key = defaultdict(list)
    for r in results:
        r["pos_file"], r["pos_match"] = "", "none"
        for d in dates_for(r):
            if by_key.get((r["pointing"], d)):
                obs_by_key[(r["pointing"], d)].append(r)
                break

    for key, robs in obs_by_key.items():
        cands = by_key[key]
        if len(cands) == 1 and len(robs) == 1:
            robs[0]["pos_file"], robs[0]["pos_match"] = cands[0]["path"], "unique"
            used.add(cands[0]["file"])
            continue
        # several obs and/or several pos files on that date: match by HH:MM
        for r in robs:
            best = None
            if r.get("start_mjd"):
                for p in cands:
                    if not p["hhmm"]:
                        continue
                    for off_h in (0, 8):
                        t = mjd_to_datetime(r["start_mjd"]) + dt.timedelta(hours=off_h)
                        dmin = abs((t.hour * 60 + t.minute) - (int(p["hhmm"][:2]) * 60 + int(p["hhmm"][2:])))
                        if best is None or dmin < best[0]:
                            best = (dmin, p)
            if best and best[0] <= 20:
                r["pos_file"], r["pos_match"] = best[1]["path"], f"time(+-{best[0]}min)"
                used.add(best[1]["file"])
            elif len(cands) == 1:
                r["pos_file"], r["pos_match"] = cands[0]["path"], "AMBIGUOUS(shared)"
                used.add(cands[0]["file"])
            else:
                r["pos_match"] = "AMBIGUOUS(unmatched)"
    for r in results:
        if r["pos_match"].startswith("AMBIGUOUS"):
            r["issues"].append(f"pos match {r['pos_match']}")
    return [p for p in pos if p["file"] not in used]


# ----------------------------------------------------------------------------
# output
# ----------------------------------------------------------------------------
OBS_FIELDS = [
    "obs_id", "project", "pointing", "epoch_dir", "epoch_date", "prefix", "processable_now",
    "pos_file", "pos_match", "n_beams_present", "missing_beams", "files_per_beam_min",
    "files_per_beam_max", "n_files", "size_bytes", "n_bad_files", "start_utc", "end_utc",
    "start_mjd", "span_s", "file_dur_s", "usable_files_per_beam", "usable_time_s", "contiguous",
    "n_runs", "n_index_gaps", "n_time_gaps", "n_partial_idx", "max_abs_gap_s", "files_per_chunk",
    "k_range", "chunk_s", "n_chunks", "n_dropped_files", "dropped_s", "tbin_s", "nchan", "nbits",
    "npol", "obsfreq_mhz", "obsbw_mhz", "src_name", "issues",
]


def write_outputs(cfg, files, results, gaps, unparsed, unused_pos, elapsed):
    out = cfg["audit_dir"]
    os.makedirs(os.path.join(out, "chunk_plans"), exist_ok=True)

    with open(os.path.join(out, "audit_files.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FILE_FIELDS, extrasaction="ignore")
        w.writeheader()
        for f in sorted(files, key=lambda x: (x["obs_id"], x["beam"], x["idx"])):
            w.writerow(f)

    with open(os.path.join(out, "audit_gaps.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["obs_id", "beam", "after_idx", "next_idx", "type", "gap_s", "n_missing"])
        w.writeheader()
        w.writerows(gaps)

    with open(os.path.join(out, "audit_observations.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=OBS_FIELDS, extrasaction="ignore")
        w.writeheader()
        for r in results:
            row = dict(r)
            row["issues"] = " | ".join(r["issues"])
            for k in ("span_s", "usable_time_s", "chunk_s", "dropped_s", "file_dur_s", "max_abs_gap_s"):
                if isinstance(row.get(k), float):
                    row[k] = f"{row[k]:.3f}"
            w.writerow(row)

    for r in results:
        plan = {k: r.get(k) for k in ("obs_id", "project", "pointing", "epoch_dir", "epoch_date", "prefix",
                                      "pos_file", "pos_match", "processable_now", "file_dur_s", "tbin_s",
                                      "nchan", "nbits", "files_per_chunk", "chunk_s", "n_chunks",
                                      "n_dropped_files", "runs", "missing_beams", "issues")}
        plan["leftover_policy"] = cfg["leftover_policy"]
        plan["chunks"] = r.get("chunks", [])
        with open(os.path.join(out, "chunk_plans", f"{r['obs_id']}.json"), "w") as fh:
            json.dump(plan, fh, indent=1)

    # ---- status json for the pipeline
    status = {
        "step": "audit", "status": "completed",
        "finished": dt.datetime.now().isoformat(timespec="seconds"),
        "elapsed_s": round(elapsed, 1), "config": {k: v for k, v in cfg.items() if k != "header_beam_set"},
        "n_observations": len(results),
        "n_processable_now": sum(r["processable_now"] for r in results),
        "observations": [{
            "obs_id": r["obs_id"], "processable_now": r["processable_now"], "pos_file": r["pos_file"],
            "n_chunks": r.get("n_chunks", 0), "files_per_chunk": r.get("files_per_chunk"),
            "chunk_plan": os.path.join(out, "chunk_plans", f"{r['obs_id']}.json"),
            "issues": r["issues"],
        } for r in results],
        "pos_files_without_raw": [p["path"] for p in unused_pos],
        "unparsed_fits": unparsed,
    }
    with open(os.path.join(out, "audit_status.json"), "w") as fh:
        json.dump(status, fh, indent=1)

    # ---- human summary
    L = []
    hr = lambda s: s / 3600.0  # noqa: E731
    now = [r for r in results if r["processable_now"]]
    L.append("=" * 100)
    L.append(f"CRAFTS RAW DATA AUDIT   {dt.datetime.now():%Y-%m-%d %H:%M}   (took {elapsed / 60:.1f} min)")
    L.append("=" * 100)
    L.append(f"raw_root : {cfg['raw_root']}  projects: {', '.join(cfg['raw_projects'])}")
    L.append(f"pos_dir  : {cfg['pos_dir']}")
    L.append("")
    L.append("OVERALL")
    L.append(f"  pointings              : {len({r['pointing'] for r in results})}")
    L.append(f"  observations (epochs)  : {len(results)}")
    L.append(f"  fits files             : {len(files)}   ({human_bytes(sum(max(f['size_bytes'], 0) for f in files))})")
    L.append(f"  unreadable/truncated   : {sum(1 for f in files if not f['ok'])}")
    L.append(f"  unparsed fits names    : {len(unparsed)}")
    L.append(f"  total observing time   : {hr(sum(r.get('span_s', 0) or 0 for r in results)):.2f} h (wall clock, per beam)")
    L.append(f"  usable (all-beam) time : {hr(sum(r.get('usable_time_s', 0) or 0 for r in results)):.2f} h")
    L.append("")
    L.append("PROCESSABLE NOW (raw data + pos.fits + >=1 chunk)")
    L.append(f"  observations           : {len(now)} / {len(results)}")
    L.append(f"  observing time         : {hr(sum(r.get('usable_time_s', 0) or 0 for r in now)):.2f} h")
    L.append(f"  chunks (per beam)      : {sum(r.get('n_chunks', 0) for r in now)}  "
             f"-> {sum(r.get('n_chunks', 0) for r in now) * cfg['n_beams']} filterbanks")
    L.append(f"  data volume            : {human_bytes(sum(r['size_bytes'] for r in now))}")
    L.append("")
    for proj in cfg["raw_projects"]:
        rs = [r for r in results if r["project"] == proj]
        if not rs:
            continue
        L.append("-" * 100)
        L.append(f"{proj}: {len(rs)} observations, {hr(sum(r.get('span_s', 0) or 0 for r in rs)):.2f} h")
        L.append(f"  {'observation':<40} {'pos':>4} {'beams':>5} {'f/beam':>7} {'span[min]':>9} "
                 f"{'runs':>4} {'k':>3} {'chunk[s]':>8} {'nchk':>4} {'drop':>4}  issues")
        for r in rs:
            fpb = (f"{r['files_per_beam_min']}" if r['files_per_beam_min'] == r['files_per_beam_max']
                   else f"{r['files_per_beam_min']}-{r['files_per_beam_max']}")
            L.append(f"  {r['obs_id']:<40} {'Y' if r['pos_file'] else '-':>4} {r['n_beams_present']:>5} {fpb:>7} "
                     f"{(r.get('span_s') or 0) / 60:>9.1f} {r.get('n_runs', 0):>4} {r.get('files_per_chunk') or '-':>3} "
                     f"{(r.get('chunk_s') or 0):>8.1f} {r.get('n_chunks', 0):>4} {r.get('n_dropped_files', 0):>4}  "
                     f"{'; '.join(r['issues']) if r['issues'] else 'ok'}")
    L.append("-" * 100)
    L.append("")
    nopos = [r for r in results if not r["pos_file"]]
    L.append(f"OBSERVATIONS WITHOUT pos.fits ({len(nopos)}) - cannot be processed yet:")
    for r in nopos:
        L.append(f"  {r['obs_id']}")
    L.append("")
    L.append(f"pos.fits WITHOUT MATCHING RAW DATA ({len(unused_pos)}):")
    for p in unused_pos:
        L.append(f"  {p['file']}")
    if unparsed:
        L.append("")
        L.append(f"UNPARSED FITS FILE NAMES ({len(unparsed)}), first 20 - check file_regex:")
        for u in unparsed[:20]:
            L.append(f"  {u}")
    L.append("")
    L.append("Columns: k = files per chunk, nchk = chunks per beam, drop = files per beam not in any chunk.")
    L.append(f"Chunking: target {cfg['target_chunk_s']:.0f}s, leftover_policy={cfg['leftover_policy']}, "
             f"min_chunk_s={cfg['min_chunk_s']:.0f}; chunks never cross a gap or a missing file.")
    txt = "\n".join(L)
    with open(os.path.join(out, "audit_summary.txt"), "w") as fh:
        fh.write(txt + "\n")
    print(txt)


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-c", "--config", required=True)
    ap.add_argument("--resume", action="store_true", help="reuse header info from a previous audit_files.csv")
    ap.add_argument("--only", default="", help="comma-separated pointings to audit (testing)")
    ap.add_argument("-o", "--audit-dir", default="", help="override audit_dir from config")
    ap.add_argument("-j", "--workers", type=int, default=0, help="override n_workers")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.audit_dir:
        cfg["audit_dir"] = args.audit_dir
    if args.workers:
        cfg["n_workers"] = args.workers
    setup_logging(cfg["audit_dir"])
    t0 = time.time()
    LOG.info("Config %s -> audit_dir %s", args.config, cfg["audit_dir"])

    only = {s.strip() for s in args.only.split(",") if s.strip()} or None
    LOG.info("Discovering raw files ...")
    files, unparsed = discover(cfg, only)
    LOG.info("Found %d fits files (%d unparsed names)", len(files), len(unparsed))
    if not files:
        LOG.error("No raw files found - check raw_root/raw_projects/file_regex")
        sys.exit(1)

    cache = load_cache(cfg["audit_dir"]) if args.resume else {}
    read_headers(files, cfg, cache)

    obs = defaultdict(list)
    for f in files:
        obs[f["obs_id"]].append(f)
    LOG.info("Analysing %d observations ...", len(obs))
    gaps, results = [], []
    for oid in sorted(obs, key=lambda o: (obs[o][0]["project"], o)):
        results.append(analyse_observation(oid, obs[oid], cfg, gaps))

    pos = scan_pos(cfg)
    if only:
        pos = [p for p in pos if p["pointing"] in only]
    unused_pos = match_pos(results, pos)
    for r in results:
        r["processable_now"] = bool(r["pos_file"]) and r.get("processable_raw", False)

    write_outputs(cfg, files, results, gaps, unparsed, unused_pos, time.time() - t0)
    LOG.info("Audit complete: %d/%d observations processable now. Outputs in %s",
             sum(r["processable_now"] for r in results), len(results), cfg["audit_dir"])


if __name__ == "__main__":
    main()
