#!/bin/bash
# crafts_feeder.sh - keep at most MAX epochs in progress; start the next epoch
# from a queue file whenever one finishes. Run it in tmux/screen or with nohup.
#
#   usage: crafts_feeder.sh queue.txt [MAX=8] [CHECK_EVERY_s=900]
#
# queue.txt: one epoch per line:  POINTING DATE [skip_up]
#   skip_up = headers already updated -> mark update_pointing done before starting
#   lines starting with # are ignored; started lines are rewritten as "# started ..."
#
# "In progress" = any epoch in `crafts.py status` that is not DONE (failed ones
# count too, so a stuck epoch never lets more than MAX pile up - fix it with
# rerun-failed and the feeder carries on).
Q=${1:?queue file}; MAX=${2:-8}; EVERY=${3:-900}
HERE=$(cd "$(dirname "$(readlink -f "$0")")" && pwd)
CR="python3 $HERE/crafts.py -c ${CRAFTS_CONFIG:-$HERE/crafts_config.ini}"
log() { echo "$(date '+%F %T') $*"; }

while true; do
    active=$($CR status 2>/dev/null | awk 'NR>1 && $1 ~ /^Dec/ && $0 !~ /DONE/' | wc -l)
    next=$(grep -v -E '^\s*(#|$)' "$Q" | head -1)
    if [ -z "$next" ]; then log "queue empty - feeder finished ($active epoch(s) still in progress)"; exit 0; fi
    if [ "$active" -ge "$MAX" ]; then sleep "$EVERY"; continue; fi
    read -r PT DT FLAG <<< "$next"
    log "in progress $active/$MAX -> starting $PT $DT ${FLAG:-}"
    if [ "$FLAG" = "skip_up" ]; then
        $CR mark-done "$PT" --date "$DT" --step update_pointing --reason "headers already updated"
    fi
    $CR run "$PT" --date "$DT"
    awk -v p="$PT" -v d="$DT" -v t="$(date '+%F_%T')" \
        '!done && $1==p && $2==d {print "# started " t " " $0; done=1; next} {print}' "$Q" > "$Q.tmp" && mv "$Q.tmp" "$Q"
    sleep 20   # let the first job register before counting again
done
