#!/usr/bin/env python3
"""
check_pointing_updated.py - READ-ONLY check whether the raw FITS of each epoch
already had their beam positions updated (update_pointings_v2.py).

Two independent signs per epoch:
  1. old log  <raw_dir>/update_pointing_logs/*.log : count of "Updated" lines vs
     number of .fits, plus "skipping" / ERROR lines
  2. headers  : RA_DEG / DEC_DEG keywords (written only by the update script) in a
     sample of files per beam (first, middle, last; --all = every file)

Verdict: UPDATED (safe to skip step 1) / PARTIAL / NOT UPDATED.
For UPDATED epochs it prints the `crafts mark-done` command to use (it does not
run it). Pure Python - only primary headers are read, no astropy needed.

Usage
  python3 check_pointing_updated.py Dec+2045_01_05 Dec+2715_01_05 ...
  python3 check_pointing_updated.py --project ZD2021_1_1_2bit          # every pointing of a project
"""
import argparse
import glob
import os
import re
import sys

RAW = "/aphid/temp/fast_crafts/data"
PROJECTS = ["ZD2020_1_1_2bit", "ZD2021_1_1_2bit"]
FRX = re.compile(r"-M(\d{2})_(\d{4})")


def primary_header(path, max_blocks=40):
    cards = {}
    with open(path, "rb") as fh:
        for _ in range(max_blocks):
            blk = fh.read(2880)
            if len(blk) < 2880:
                break
            for i in range(0, 2880, 80):
                c = blk[i:i + 80].decode("ascii", "replace")
                k = c[:8].strip()
                if k == "END":
                    return cards
                if c[8:10] == "= ":
                    cards[k] = c[10:].split("/")[0].strip().strip("'").strip()
    return cards


def check_epoch(edir, all_files=False):
    fits = sorted(f for f in os.listdir(edir) if f.endswith(".fits"))
    by_beam = {}
    for f in fits:
        m = FRX.search(f)
        if m:
            by_beam.setdefault(int(m.group(1)), []).append(f)
    sample = []
    for b, fl in sorted(by_beam.items()):
        sample += fl if all_files else sorted({fl[0], fl[len(fl) // 2], fl[-1]})
    with_kw = 0
    example = ""
    for f in sample:
        try:
            h = primary_header(os.path.join(edir, f))
        except OSError:
            continue
        if "RA_DEG" in h and "DEC_DEG" in h:
            with_kw += 1
            example = example or f"{f}: RA={h.get('RA')} DEC={h.get('DEC')}"
    logs = glob.glob(os.path.join(edir, "update_pointing_logs", "*.log"))
    n_up = n_skip = n_err = 0
    for lf in logs:
        t = open(lf, errors="replace").read()
        n_up += len(re.findall(r" Updated ", t))
        n_skip += len(re.findall(r"skipping", t))
        n_err += len(re.findall(r" - ERROR - ", t))
    n = len(fits)
    hdr_ok = sample and with_kw == len(sample)
    log_ok = logs and n_up >= n and n_err == 0
    if hdr_ok and (log_ok or not logs):
        verdict = "UPDATED"
    elif with_kw == 0 and n_up == 0:
        verdict = "NOT UPDATED"
    else:
        verdict = "PARTIAL"
    return {"n_fits": n, "sampled": len(sample), "with_kw": with_kw, "logs": len(logs),
            "log_updated": n_up, "log_skipped": n_skip, "log_errors": n_err,
            "verdict": verdict, "example": example}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pointing", nargs="*")
    ap.add_argument("--project", action="append")
    ap.add_argument("--raw-root", default=RAW)
    ap.add_argument("--all", action="store_true", help="read every file's header, not a sample")
    a = ap.parse_args()
    projects = a.project or PROJECTS
    todo = []
    for proj in projects:
        pdir = os.path.join(a.raw_root, proj)
        if not os.path.isdir(pdir):
            continue
        for pt in sorted(os.listdir(pdir)):
            if a.pointing and pt not in a.pointing:
                continue
            for ep in sorted(os.listdir(os.path.join(pdir, pt))):
                if os.path.isdir(os.path.join(pdir, pt, ep)):
                    todo.append((proj, pt, ep))
    if not todo:
        sys.exit("no epochs found")
    print(f"{'pointing':<22}{'epoch':<10}{'fits':>7}{'hdr RA_DEG':>12}{'log upd':>9}{'skip':>6}{'err':>5}  verdict")
    marks = []
    for proj, pt, ep in todo:
        r = check_epoch(os.path.join(a.raw_root, proj, pt, ep), a.all)
        print(f"{pt:<22}{ep:<10}{r['n_fits']:>7}{r['with_kw']:>5}/{r['sampled']:<6}"
              f"{(r['log_updated'] if r['logs'] else '-')!s:>9}{r['log_skipped']:>6}{r['log_errors']:>5}  {r['verdict']}",
              flush=True)
        if r["verdict"] == "UPDATED":
            marks.append(f"crafts mark-done {pt} --date {ep} --step update_pointing --reason 'updated in old run'")
    print("\nhdr RA_DEG = sampled files whose header has the keywords the update script writes;"
          "\nlog upd = 'Updated' lines in the old update_pointing_logs (- = no old log).")
    if marks:
        print("\nFor UPDATED epochs, after clearing any old processing folder, skip step 1 with:")
        print("\n".join("  " + m for m in marks))


if __name__ == "__main__":
    main()
