#!/bin/bash
#SBATCH --account=oz002
#SBATCH --job-name=fold
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=01:00:00
#SBATCH --partition=${SYS_ARCH}
# Step 8: one task = one line of fold_commands_<epoch>.sh (one beam x one chunk).
# Task line: id n_candidates outdir command. Time/mem are set per size class by crafts.py.
CRAFTS_NEW=1
source "${CRAFTS_EPOCH_ENV:?CRAFTS_EPOCH_ENV not set}"; source "${CRAFTS_STEPS_DIR}/common.sh"
run_task() {
    NCANDS=${F[1]}; OUTDIR=${F[2]}; CMD=${F[3]}
    echo "Running task $TASK_ID ($NCANDS candidates)"
    echo "$CMD"
    cd "${FOLD_DIR:-$SCRIPTS_DIR}"     # commands call fold_pipeline_v3.py by relative name
    # [pipeline] fold_script: run this fold script instead of the one named in the command
    if [ -n "${FOLD_SCRIPT:-}" ]; then
        CMD=$(echo "$CMD" | sed -E "s#(python[0-9.]* +)[^ ]*fold_pipeline[^ ]*\.py#\1${FOLD_SCRIPT}#")
        echo "fold script override -> $CMD"
    fi
    bash -c "$CMD"
    return $?
}
crafts_main
