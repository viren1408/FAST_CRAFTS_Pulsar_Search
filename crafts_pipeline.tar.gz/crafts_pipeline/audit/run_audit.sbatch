#!/bin/bash
#SBATCH --job-name=crafts_audit
#SBATCH --output=/fred/oz002/users/vmandaog/pulsar_search/FAST/test_pulsars/audit_reprocessing/slurm_audit_%j.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=16G
#SBATCH --time=02:00:00
##SBATCH --account=oz002

# Header reads are I/O bound on /aphid; 16 workers is a reasonable start.
# Use --resume on a re-run to skip files whose headers were already read.

set -euo pipefail
# --- activate the python env that has astropy (edit to match yours) ---
# module load python-scientific    # or:
# source ~/miniconda3/bin/activate pulsar

SCRIPT_DIR=/aphid/temp/fast_crafts/crafts_processing/crafts_pipeline/audit
CONFIG=${CONFIG:-/aphid/temp/fast_crafts/crafts_processing/crafts_pipeline/automation/crafts_config.ini}

mkdir -p /fred/oz002/users/vmandaog/pulsar_search/FAST/test_pulsars/audit_reprocessing
python3 "$SCRIPT_DIR/audit_raw.py" -c "$CONFIG" -j "${SLURM_CPUS_PER_TASK:-16}" "$@"
