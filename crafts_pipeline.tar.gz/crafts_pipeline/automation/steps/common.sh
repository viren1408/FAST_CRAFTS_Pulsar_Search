# Sourced by every step wrapper.
#
# New wrappers (CRAFTS_NEW=1) define run_task() and then call crafts_main, which
# runs CRAFTS_PACK consecutive lines of the task list in this one job, writing
# START/END markers (with exit code) for each line to stdout AND stderr, so the
# check job can judge every line separately.
#
# Old wrappers (no CRAFTS_NEW) get the original behaviour: one line, F[] set
# here, crafts_end at the end. Kept so jobs already queued keep working.
set -o pipefail
source "${CRAFTS_EPOCH_ENV:?CRAFTS_EPOCH_ENV not set}"
[ -n "${ENV_ACTIVATE:-}" ] && [ -f "$ENV_ACTIVATE" ] && source "$ENV_ACTIVATE"

_crafts_line() {   # _crafts_line <index> -> sets F[] and TASK_ID, returns 1 if no such line
    local L
    L=$(sed -n "$(( $1 + 1 ))p" "$CRAFTS_TASKS")
    [ -z "$L" ] && return 1
    IFS=$'\t' read -r -a F <<< "$L"
    TASK_ID=${F[0]}
}

if [ -z "${CRAFTS_NEW:-}" ]; then
    T0=$(date +%s)
    if [ -n "${CRAFTS_TASKS:-}" ]; then
        IDX=$(( ${CRAFTS_OFFSET:-0} + ${SLURM_ARRAY_TASK_ID:-0} ))
        _crafts_line "$IDX" || { echo "CRAFTS: no task line $IDX in $CRAFTS_TASKS"; exit 2; }
    fi
    echo "CRAFTS_TASK_START step=${CRAFTS_STEP} epoch=${POINTING}/${EPOCH} task=${TASK_ID:-0} job=${SLURM_JOB_ID:-} host=$(hostname) time=$(date -Is)"
    crafts_end() {
        echo "CRAFTS_TASK_END step=${CRAFTS_STEP} task=${TASK_ID:-0} exit=$1 elapsed_s=$(( $(date +%s) - T0 ))"
        exit "$1"
    }
fi

crafts_main() {
    local PACK=${CRAFTS_PACK:-1}
    local BASE=$(( ${CRAFTS_OFFSET:-0} + ${SLURM_ARRAY_TASK_ID:-0} * PACK ))
    local OVERALL=0 k RC T0
    echo "CRAFTS_JOB job=${SLURM_JOB_ID:-} array=${SLURM_ARRAY_TASK_ID:-} pack=$PACK host=$(hostname) gpu=${CUDA_VISIBLE_DEVICES:-none}"
    for (( k = 0; k < PACK; k++ )); do
        _crafts_line $(( BASE + k )) || break
        T0=$(date +%s)
        echo "CRAFTS_TASK_START step=${CRAFTS_STEP} epoch=${POINTING}/${EPOCH} task=${TASK_ID} time=$(date -Is)"
        echo "CRAFTS_TASK_START step=${CRAFTS_STEP} task=${TASK_ID}" >&2
        ( run_task )
        RC=$?
        echo "CRAFTS_TASK_END step=${CRAFTS_STEP} task=${TASK_ID} exit=${RC} elapsed_s=$(( $(date +%s) - T0 ))"
        echo "CRAFTS_TASK_END step=${CRAFTS_STEP} task=${TASK_ID} exit=${RC}" >&2
        [ $RC -ne 0 ] && OVERALL=$RC
    done
    exit $OVERALL
}
